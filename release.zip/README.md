# SpaceTrackChecker

* usage

 - Basic

 1. get account from space-track.org
 2. add id and password to the ini file "conf/space_track.ini"
 3. execute jar file "stchkr.jar". 

  > java -jar stchkr.jar

 - Windows

 You can use bat file. You can also use task scheduler on windows OS. 
